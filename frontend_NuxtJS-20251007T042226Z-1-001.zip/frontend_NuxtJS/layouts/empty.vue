<template>
  <div>
    <nuxt />
  </div>
</template>
