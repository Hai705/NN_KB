import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _4f712afc = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _1c553abc = () => interopDefault(import('..\\pages\\account\\index.vue' /* webpackChunkName: "pages/account/index" */))
const _6bf47d80 = () => interopDefault(import('..\\pages\\admin\\index.vue' /* webpackChunkName: "pages/admin/index" */))
const _510549e5 = () => interopDefault(import('..\\pages\\cart\\index.vue' /* webpackChunkName: "pages/cart/index" */))
const _5eefba62 = () => interopDefault(import('..\\pages\\contact\\index.vue' /* webpackChunkName: "pages/contact/index" */))
const _1fdcd421 = () => interopDefault(import('..\\pages\\order\\index.vue' /* webpackChunkName: "pages/order/index" */))
const _30a240c6 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _18fae0a0 = () => interopDefault(import('..\\pages\\wishlist\\index.vue' /* webpackChunkName: "pages/wishlist/index" */))
const _45ffcc74 = () => interopDefault(import('..\\pages\\admin\\contact\\index.vue' /* webpackChunkName: "pages/admin/contact/index" */))
const _00d837fb = () => interopDefault(import('..\\pages\\admin\\orders\\index.vue' /* webpackChunkName: "pages/admin/orders/index" */))
const _d151b2c8 = () => interopDefault(import('..\\pages\\admin\\products\\index.vue' /* webpackChunkName: "pages/admin/products/index" */))
const _bda16228 = () => interopDefault(import('..\\pages\\admin\\recyclebin\\index.vue' /* webpackChunkName: "pages/admin/recyclebin/index" */))
const _0b8a040c = () => interopDefault(import('..\\pages\\admin\\users\\index.vue' /* webpackChunkName: "pages/admin/users/index" */))
const _65695ab7 = () => interopDefault(import('..\\pages\\admin\\products\\add\\index.vue' /* webpackChunkName: "pages/admin/products/add/index" */))
const _eabd0b28 = () => interopDefault(import('..\\pages\\product_detail\\_id.vue' /* webpackChunkName: "pages/product_detail/_id" */))
const _7daf84c5 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _4f712afc,
    name: "about"
  }, {
    path: "/account",
    component: _1c553abc,
    name: "account"
  }, {
    path: "/admin",
    component: _6bf47d80,
    name: "admin"
  }, {
    path: "/cart",
    component: _510549e5,
    name: "cart"
  }, {
    path: "/contact",
    component: _5eefba62,
    name: "contact"
  }, {
    path: "/order",
    component: _1fdcd421,
    name: "order"
  }, {
    path: "/search",
    component: _30a240c6,
    name: "search"
  }, {
    path: "/wishlist",
    component: _18fae0a0,
    name: "wishlist"
  }, {
    path: "/admin/contact",
    component: _45ffcc74,
    name: "admin-contact"
  }, {
    path: "/admin/orders",
    component: _00d837fb,
    name: "admin-orders"
  }, {
    path: "/admin/products",
    component: _d151b2c8,
    name: "admin-products"
  }, {
    path: "/admin/recyclebin",
    component: _bda16228,
    name: "admin-recyclebin"
  }, {
    path: "/admin/users",
    component: _0b8a040c,
    name: "admin-users"
  }, {
    path: "/admin/products/add",
    component: _65695ab7,
    name: "admin-products-add"
  }, {
    path: "/product_detail/:id?",
    component: _eabd0b28,
    name: "product_detail-id"
  }, {
    path: "/",
    component: _7daf84c5,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
